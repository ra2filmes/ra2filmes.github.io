# Site da RA2 Filmes
Site estático simples (HTML + CSS + JS) pronto para publicar no **GitHub Pages** e usar o domínio **www.ra2filmes.com.br**.

## Como publicar (GitHub Pages)
1. Crie uma conta no GitHub (se ainda não tiver) e faça login.
2. Crie um repositório chamado **ra2filmes.github.io** *(ou qualquer nome)*.
3. Faça upload de todos os arquivos desta pasta para o repositório.
4. Vá em **Settings → Pages** e, em **Build and deployment → Source**, selecione **Deploy from a branch**.
5. Em **Branch**, escolha **main** e a pasta **/** (root). Salve.
6. Em **Custom domain**, digite: **www.ra2filmes.com.br** e salve. O GitHub criará/validará o arquivo **CNAME**.

## DNS no Registro.br
No painel do Registro.br, configure a **Zona DNS** do domínio:
- CNAME **www** → **SEU-USUÁRIO.github.io**  (substitua SEU-USUÁRIO pelo seu login do GitHub)
- A **@** → 185.199.108.153
- A **@** → 185.199.109.153
- A **@** → 185.199.110.153
- A **@** → 185.199.111.153

> Esses são os IPs oficiais do GitHub Pages. O **www** será o domínio principal e o **@** (ra2filmes.com.br) redirecionará para o **www**.

## Editar o conteúdo
- Edite os cards de obras em **index.html** (procure pela seção `Trabalhos em destaque`).
- Troque o e-mail de contato em `mailto:` (se preferir outro).
- Coloque seus links de IMDb/Instagram/YouTube nos botões/rodapé.
- Substitua o logo em **assets/img/logo.svg** se desejar.

Bom lançamento! 🎬
