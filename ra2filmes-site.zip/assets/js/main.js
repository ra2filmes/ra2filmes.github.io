// Pequeno JS: atualiza ano do rodapé
document.getElementById('year').textContent = new Date().getFullYear();
